require 'sinatra'

post "/accounts" do
  name = params[:name]
  puts "creating a user named: #{name}"
  raise "Oh no! #{name} is already in use." if name == "Todd"
  status 201
end
