(function() {
  var _ref,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  window.SignUpView = (function(_super) {
    __extends(SignUpView, _super);

    function SignUpView() {
      _ref = SignUpView.__super__.constructor.apply(this, arguments);
      return _ref;
    }

    SignUpView.prototype.template = 'app/templates/sign-up-form.us';

    SignUpView.prototype.events = {
      "submit form": "createAccount",
      "change [name='login']": "checkAvailability"
    };

    SignUpView.prototype.render = function() {
      return this.$el.html(JST[this.template]());
    };

    SignUpView.prototype.createAccount = function(e) {
      e.preventDefault();
      return $.post('/accounts', {
        name: this.$('[name="login"]').val()
      });
    };

    SignUpView.prototype.checkAvailability = function() {
      var $name;
      $name = this.$('[name="login"]');
      return $.get("/account_availability/" + ($name.val()), function(response) {
        return $name.toggleClass('invalid', !response.available);
      });
    };

    return SignUpView;

  })(Backbone.View);

  $(function() {
    return new SignUpView({
      el: $('.container')
    }).render();
  });

}).call(this);
