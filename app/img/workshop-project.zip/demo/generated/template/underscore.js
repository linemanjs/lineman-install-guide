this["JST"] = this["JST"] || {};

this["JST"]["app/templates/homepage.us"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<!DOCTYPE html>\n<html>\n  <head>\n    <title>' +
((__t = ( pkg.name )) == null ? '' : __t) +
'</title>\n\n    <link rel="stylesheet" type="text/css" href="' +
((__t = ( css )) == null ? '' : __t) +
'" media="all" />\n  </head>\n  <body>\n    <div class="container"></div>\n    <script type="text/javascript" src="' +
((__t = ( js )) == null ? '' : __t) +
'"></script>\n  </body>\n</html>\n';

}
return __p
};

this["JST"]["app/templates/sign-up-form.us"] = function(obj) {
obj || (obj = {});
var __t, __p = '', __e = _.escape;
with (obj) {
__p += '<div class="create-account">\n  <form>\n    <fieldset>\n      <legend>Sign Up</legend>\n      <label>User name</label>\n      <input type="text" name="login" placeholder="joeschmoe96">\n      <label>E-mail</label>\n      <input type="text" name="email" placeholder="jschmoe@gmail.com">\n      <label>Password</label>\n      <input type="password" name="password">\n      <label>Confirm Password</label>\n      <input type="password" name="passwordConfirmation">\n    </fieldset>\n    <button class="btn btn-primary">Create Account</button>\n  </form>\n</div>\n';

}
return __p
};