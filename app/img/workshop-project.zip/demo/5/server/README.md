To start this server:

```
$ npm install
$ node main.js
```
